# imcon

*imcon* is a python package for controlling imaging systems such as those used for scientific observations.

## Installation

Download the code (usually into the *imcon* root folder such as `/data/imcon`) and install.

```shell
mkdir /data/imcon
cd /data/imcon
git clone https://github.com/mplesser/imcon
pip install -e imcon
```
